from __future__ import annotations

from random_gen import RandomGen
from team import MonsterTeam
from monster_base import MonsterBase
from battle import Battle

from elements import Element

from data_structures.referential_array import ArrayR
from data_structures.queue_adt import CircularQueue
from data_structures.bset import BSet

class BattleTower:

    MIN_LIVES = 2
    MAX_LIVES = 10

    def __init__(self, battle: Battle|None=None) -> None:
        self.battle = battle or Battle(verbosity=0)
        self.out_meta = BSet()
        self.start = False

    def set_my_team(self, team: MonsterTeam) -> None:
        # Generate the team lives here too.
        self.team = team
        self.lives = RandomGen.randint(self.MIN_LIVES,self.MAX_LIVES)

    def generate_teams(self, n: int) -> None:
        # Generate an array containing the enemy teams
        self.enemy_teams = CircularQueue(n*2)
        self.meta = CircularQueue(n*2)

        # Helper for out_of_meta
        self.enemy_index = 0

        for i in range(n):
            enemy = MonsterTeam(MonsterTeam.TeamMode.BACK, MonsterTeam.SelectionMode.RANDOM)
            enemy_lives = RandomGen.randint(self.MIN_LIVES,self.MAX_LIVES)

            self.enemy_teams.append(enemy)
            self.enemy_teams.append(enemy_lives)

            self.meta.append(enemy)
            self.meta.append(enemy_lives)

    def battles_remaining(self) -> bool:

        # print(f"our lives: {self.lives}")
        # print(f"enemy num: {len(self.enemy_teams)}")

        return len(self.enemy_teams) and (self.lives > 0)

    def next_battle(self) -> tuple[Battle.Result, MonsterTeam, MonsterTeam, int, int]:

        # Regenerate teams and log enemy lives
        self.team.regenerate_team()

        current_enemy: MonsterTeam = self.enemy_teams.serve()
        current_enemy.regenerate_team()
        current_enemy_lives = self.enemy_teams.serve()

        # Calling the battle
        result = self.battle.battle(team1=self.team, team2=current_enemy)

        # Decrementing lives according to battle result
        if result == self.battle.Result.TEAM1:
            current_enemy_lives -= 1

            # Fight the player again if at least 1 life still remains
            if current_enemy_lives > 0:
                self.enemy_teams.append(current_enemy)
                self.enemy_teams.append(current_enemy_lives)

        elif result == self.battle.Result.TEAM2:
            self.lives -= 1

            self.enemy_teams.append(current_enemy)
            self.enemy_teams.append(current_enemy_lives)

        else:
            current_enemy_lives -= 1
            self.lives -= 1

            if current_enemy_lives > 0:
                self.enemy_teams.append(current_enemy)
                self.enemy_teams.append(current_enemy_lives)

        self.start = True
        return (result, self.team, current_enemy, self.lives, current_enemy_lives)

    def out_of_meta(self) -> ArrayR[Element]:

        if not self.start:
            return ArrayR(len(self.out_meta))

        self.team.regenerate_team()

        # BSet for my team
        team_elements = BSet()

        # Storing the value of monster element in my team into team_elements
        for team_index in range(len(self.team)):
            monster = self.team.team.array[team_index]
            monster_element = Element.from_string(monster.get_element())
            team_elements.add(monster_element.value)

        try:
            # BSet for current team
            current_enemy_team: MonsterTeam = self.meta.array[self.enemy_index]
        except IndexError:
            self.enemy_index = 0
            current_enemy_team: MonsterTeam = self.meta.array[self.enemy_index]

        current_enemy_team.regenerate_team()

        current_enemy_elements = BSet()

        # Storing the value of monster element in my team into team_elements
        for current_index in range(len(current_enemy_team)):
        # for current_enemy in self.enemy_teams.array[self.enemy_index]:
            current_enemy: MonsterBase = current_enemy_team.team.array[current_index]
            current_enemy_element = Element.from_string(current_enemy.get_element())
            current_enemy_elements.add(current_enemy_element.value)

        try:
            self.enemy_index += 2
            next_enemy_team: MonsterTeam = self.meta.array[self.enemy_index]

        except IndexError:
            self.enemy_index = 0
            next_enemy_team: MonsterTeam = self.meta.array[self.enemy_index]

        next_enemy_team.regenerate_team()
        next_enemy_elements = BSet()

        for next_index in range(len(next_enemy_team)):
            next_enemy: MonsterBase = next_enemy_team.team.array[next_index]
            next_enemy_element = Element.from_string(next_enemy.get_element())
            next_enemy_elements.add(next_enemy_element.value)

        self.out_meta = self.out_meta.union(team_elements)
        self.out_meta = self.out_meta.union(current_enemy_elements)

        self.out_meta = self.out_meta.difference(next_enemy_elements)
        self.out_meta = self.out_meta.difference(team_elements)

        result = ArrayR(len(self.out_meta))
        index = 0

        for element in Element:
            if element.value in self.out_meta:
                result.array.__setitem__(index, element)
                index += 1

        return result

if __name__ == "__main__":

    # RandomGen.set_seed(129371)

    # bt = BattleTower(Battle(verbosity=3))
    # bt.set_my_team(MonsterTeam(MonsterTeam.TeamMode.BACK, MonsterTeam.SelectionMode.RANDOM))
    # bt.generate_teams(3)

    from helpers import Flamikin, Faeboa

    RandomGen.set_seed(123456789)
    bt = BattleTower(Battle(verbosity=0))
    bt.set_my_team(MonsterTeam(
        team_mode=MonsterTeam.TeamMode.BACK,
        selection_mode=MonsterTeam.SelectionMode.PROVIDED,
        provided_monsters=ArrayR.from_list([Faeboa])
    ))
    bt.generate_teams(3)

    print(bt.out_of_meta())