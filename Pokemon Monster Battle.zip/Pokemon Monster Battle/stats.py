import abc
import math

from data_structures.referential_array import ArrayR
from data_structures.stack_adt import ArrayStack

class Stats(abc.ABC):

    @abc.abstractmethod
    def get_attack(self):
        pass

    @abc.abstractmethod
    def get_defense(self):
        pass

    @abc.abstractmethod
    def get_speed(self):
        pass

    @abc.abstractmethod
    def get_max_hp(self):
        pass

class SimpleStats(Stats):

    def __init__(self, attack, defense, speed, max_hp) -> None:
        self.attack = attack
        self.defense = defense
        self.speed = speed
        self.max_hp = max_hp

    def get_attack(self):
        return self.attack

    def get_defense(self):
        return self.defense

    def get_speed(self):
        return self.speed

    def get_max_hp(self):
        return self.max_hp

class ComplexStats(Stats):

    def __init__(
        self,
        attack_formula: ArrayR[str],
        defense_formula: ArrayR[str],
        speed_formula: ArrayR[str],
        max_hp_formula: ArrayR[str],
    ) -> None:
        
        self.attack_formula = attack_formula
        self.defense_formula = defense_formula
        self.speed_formula = speed_formula
        self.max_hp_formula = max_hp_formula

    def get_attack(self, level: int) -> int:
        """ Complexity O(n) where n is the length of list attack_formula """
        return self.get_stats(self.attack_formula, level)

    def get_defense(self, level: int) -> int:
        """ Complexity O(n) where n is the length of list defense_formula """
        return self.get_stats(self.defense_formula, level)

    def get_speed(self, level: int) -> int:
        """ Complexity O(n) where n is the length of list speed_formula """
        return self.get_stats(self.speed_formula, level)

    def get_max_hp(self, level: int) -> int:
        """ Complexity O(n) where n is the length of list max_hp_formula """
        return self.get_stats(self.max_hp_formula, level)
    
    def get_stats(self, formula: ArrayR[str], level: int) -> int:
        """
        General algorithm to find the values of complex stats

        :param formula: the formula to compute stat in the form of an array
        :param level: the formula to compute stat in the form of an array

        :returns: an integer representing the result of the formula calculated
        :complexity: O(n) best/worst case, where
            n is the length of the formula list. It will become the max_capacity when initializing 
            the ArrayStack since it will be greater than MIN_CAPACITY
        """
        operand_list = ArrayStack(len(formula))

        # Push all the operands into the ArrayStack operand_list
        for item in formula:
            # O(1) for all methods below
            if item.isnumeric():
                operand_list.push(int(item))
            elif item == "level":
                operand_list.push(level)
            # Compute the operation if there is any operator encountered
            else:
                result = self.compute(operand_list,item)               
                operand_list.push(result)

        return int(operand_list.pop())

    def compute(self, operand_list: ArrayStack, item: str) -> int | float:
        """
        Make a computation upon the operand list and the item provided

        :param operand_list: an ArrayStack containing all the numbers to be computed
        :item: the operation that neeeds to be done on the operand list

        :returns: a number calculated using the parameters provided
        :complexity: O(1) best/worst case
            because pop(), find_median() and some other mathematical operations are all constant time
        """
        # Square root the first number on top of operand_list
        if item == "sqrt":
            operand = operand_list.pop()

            return math.sqrt(operand)

        # Find the median using the first 3 numbers on top of operand_list
        elif item == "middle":
            operand_1 = operand_list.pop()
            operand_2 = operand_list.pop()
            operand_3 = operand_list.pop()

            return self.find_median(operand_1, operand_2, operand_3)
        
        # Apply basic operations on the first 2 numbers on top of operand_list
        else:
            operand_1 = operand_list.pop()
            operand_2 = operand_list.pop()

            if item == "+":
                return operand_2 + operand_1
            elif item == "-":
                return operand_2 - operand_1
            elif item == "*":
                return operand_2 * operand_1
            elif item == "/":
                return operand_2 / operand_1
            elif item == "power":
                return operand_2 ** operand_1
            
    def find_median(self, a: int, b: int, c: int) -> int:
        """
        Find the median of 3 numbers a, b, c

        :returns: the median
        :complexity: O(1) best/worst case
        """
        if (c <= a and a <= b) or (b <= a and a <= c):
            return a
        elif (a <= b and b <= c) or (c <= b and b <= a):
            return b
        
        return c