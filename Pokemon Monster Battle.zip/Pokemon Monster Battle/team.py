from __future__ import annotations
from enum import auto
from math import ceil
from typing import Optional, TYPE_CHECKING

from base_enum import BaseEnum
from monster_base import MonsterBase
from random_gen import RandomGen
from helpers import get_all_monsters

from data_structures.referential_array import ArrayR

from data_structures.stack_adt import ArrayStack
from data_structures.queue_adt import CircularQueue
from data_structures.array_sorted_list import ArraySortedList
from data_structures.sorted_list_adt import ListItem

if TYPE_CHECKING:
    from battle import Battle

class MonsterTeam:

    class TeamMode(BaseEnum):

        FRONT = auto()
        BACK = auto()
        OPTIMISE = auto()

    class SelectionMode(BaseEnum):

        RANDOM = auto()
        MANUAL = auto()
        PROVIDED = auto()

    class SortMode(BaseEnum):

        HP = auto()
        ATTACK = auto()
        DEFENSE = auto()
        SPEED = auto()
        LEVEL = auto()

    TEAM_LIMIT = 6

    def __init__(self, team_mode: TeamMode, selection_mode, **kwargs) -> None:
        """
        :complexity: depends on make_copy() - reference below

        :best-case:  O(n) if team_mode is either FRONT or BACK
        :worst-case: O(n * log n) if team_mode is OPTIMISE
        """
        # Add any preinit logic here.
        self.team_mode = team_mode

        if team_mode == MonsterTeam.TeamMode.FRONT:
            self.team = ArrayStack(self.TEAM_LIMIT)
        elif team_mode == MonsterTeam.TeamMode.BACK:         
            self.team = CircularQueue(self.TEAM_LIMIT)
        elif team_mode == MonsterTeam.TeamMode.OPTIMISE:
            # Assigning key according to sort_key
            # and also initial a special_count to help with the special() method
            self.key = kwargs['sort_key']
            self.special_count = 0
            self.team = ArraySortedList(self.TEAM_LIMIT)

        if selection_mode == self.SelectionMode.RANDOM:
            self.select_randomly()
        elif selection_mode == self.SelectionMode.MANUAL:
            self.select_manually()
        elif selection_mode == self.SelectionMode.PROVIDED:
            self.provided_monsters = kwargs['provided_monsters']
            self.select_provided(self.provided_monsters)
        else:
            raise ValueError(f"selection_mode {selection_mode} not supported.")
        
        self.initial = self.make_copy(self.team)

    def make_copy(self, team: ArrayStack|CircularQueue|ArraySortedList) -> ArrayStack|CircularQueue|ArraySortedList:
        """
        :param team: the list to be copied
        :returns: the copied version of parameter 'team'

        :complexity: O(n * log n), where
            n is the number of elements in 'team'

            :best-case:  O(n) if team_mode is either FRONT or BACK
            :worst-case: O(n * log n) if team_mode is OPTIMISE since it uses the
                _index_to_add() to add element using a binary-search algorithm
        """
        if self.team_mode == MonsterTeam.TeamMode.FRONT:
            copy = ArrayStack(self.TEAM_LIMIT) 
        elif self.team_mode == MonsterTeam.TeamMode.BACK:         
            copy = CircularQueue(self.TEAM_LIMIT) 
        elif self.team_mode == MonsterTeam.TeamMode.OPTIMISE:
            copy = ArraySortedList(self.TEAM_LIMIT)

        for i in range(len(team)):
            monster = team.array[i].value if self.team_mode == MonsterTeam.TeamMode.OPTIMISE else team.array[i]
            initial_monster: MonsterBase = monster.__class__()

            # Adding monsters to team according to team_mode
            if self.team_mode == MonsterTeam.TeamMode.FRONT:
                copy.push(initial_monster)
            elif self.team_mode == MonsterTeam.TeamMode.BACK:
                copy.append(initial_monster)
            else:
                initial_value = initial_monster.get_max_hp()*-1
                copy.add(ListItem(value=initial_monster, key=initial_value))

        return copy

    def add_to_team(self, monster: MonsterBase):
        """
        :complexity:
            team_mode FRONT: best/worst = O(1)
            team_mode BACK: best/worst = O(1)
            team_mode OPTIMISE: 
                best = O(1) when team is empty
                worst = O(log n) when team is not empty, _index_to_add() uses binary search to add elements

            where n is the number of elements in self.team
        """
        if self.team.is_full():
            raise ValueError("Team is already full!")
        
        # Adding monsters to team list according to team_mode
        if self.team_mode == MonsterTeam.TeamMode.FRONT:
            self.team.push(monster)
        elif self.team_mode == MonsterTeam.TeamMode.BACK:
            self.team.append(monster)
        else:
            # Assigning monster_key according to sort_key
            if self.key == MonsterTeam.SortMode.HP:
                monster_key = monster.get_hp()
            elif self.key == MonsterTeam.SortMode.ATTACK:
                monster_key = monster.get_attack()
            elif self.key == MonsterTeam.SortMode.DEFENSE:
                monster_key = monster.get_defense()
            elif self.key == MonsterTeam.SortMode.SPEED:
                monster_key = monster.get_speed()
            elif self.key == MonsterTeam.SortMode.LEVEL:
                monster_key = monster.get_level()

            # Monster team will be added in descending order if special_count is even
            # or added in ascending order if special_count is odd
            if self.special_count % 2 == 0:
                monster_key *= -1

            self.team.add(ListItem(value=monster,key=monster_key))

    def retrieve_from_team(self) -> MonsterBase:
        """
        :complexity:
            team_mode FRONT: best/worst = O(1)
            team_mode BACK: best/worst = O(1)
            team_mode OPTIMISE: best/worst = O(n)
                since we delete element at index 0 using elete_at_index()
                and shuffle all other elements to the left up until the end

            where n is the number of elements in self.team
        """
        if self.team.is_empty():
            raise Exception("Team is empty!")
        
        # Getting monsters from the team according to team_mode
        if self.team_mode == MonsterTeam.TeamMode.FRONT:
            return self.team.pop()
        if self.team_mode == MonsterTeam.TeamMode.BACK:
            return self.team.serve()
        else:
            return self.team.delete_at_index(0).value

    def special(self) -> None:
        """
        :complexity:

            :best-case: O(1) where team_mode is FRONT
            :worst-case: O(n^2) where team_mode is OPTIMISE

            where n is the number of elements in self.team
            refer to each method provided for further complexity analysis
        """
        if self.team.is_empty():
            raise Exception("Cannot do special on an empty team!")
        
        n = len(self.team)

        # Calling different special methods according to team_mode
        if self.team_mode == MonsterTeam.TeamMode.FRONT:
            self.special_front(n)
        elif self.team_mode == MonsterTeam.TeamMode.BACK and n >= 2:
            self.special_back(n)
        elif self.team_mode == MonsterTeam.TeamMode.OPTIMISE:
            self.special_optimise(n)

    def special_front(self, n: int) -> None:
        """ 
        :complexity:

            :best-case: O(n) thus O(1) when n < 3, since n will be a positive integer < 3
            :worst-case: O(3) thus O(1) when n >= 3

            where n is the number of elements in self.team
            Queue and Stack methods used are all O(1)

            *** Note: the constant 3 is used here, but it is subject to change
        """
        # Here, we create a Queue 'temp' of length 3 for team with 3 or more monsters
        # Otherwise it will be the team length itself
        capacity = min(3, n)
        temp = CircularQueue(capacity)

        # Appending the last 3 monsters into temp if capacity is 3
        # Or append the last 1 or 2 monster if capacity is n
        while not temp.is_full():
            temp.append(self.team.pop())
        
        # Pushing the monsters in temp back into self.team in reversing order
        while not temp.is_empty():
                self.team.push(temp.serve())

    def special_back(self, n: int) -> None:
        """ 
        :complexity:

            :best = worst: O(n), since we have to iterate through every element
                in self.team to fill into temp1 and temp2, and then iterate for
                the same number of times to chuck them back into self.team

            where n is the number of elements in self.team
            Queue and Stack methods, as well as operation used are all O(1)
        """
        # Here, we create 2 lists. 'temp_1' is a Stack and 'temp_2' is a Queue
        # In an odd team size, the middle monster will be in temp_1 (the bottom half)
        mid = (n + 1) // 2

        temp_1 = ArrayStack(mid)
        temp_2 = CircularQueue(n - mid)

        # Adding the first half into temp_2,
        # and the bottom half into temp_1
        for _ in range(n):
            if temp_2.is_full():
                temp_1.push(self.team.serve())
            else:
                temp_2.append(self.team.serve())

        self.team.clear()

        # Adding monsters in temp_1 back into self.team (in reverse order)
        # and then adding monsters in temp_2 back into self.team (order maintained)
        for _ in range(n):
            if temp_1.is_empty():
                self.team.append(temp_2.serve())
            else:
                self.team.append(temp_1.pop())

    def special_optimise(self, n: int) -> None:
        """ 
        :complexity:

            :best = worst: O(n*n) = O(n^2)

            since delete_at_index(0) takes n times to shuffle elements to the left
            and add() also takes n times to add elements into the end of the list => O(n)

            and they are all nested in the while loop, which loops through every element
            in self.team => O(n)

            where n is the number of elements in self.team
        """
        # Create a new Array Sorted List 'temp'
        temp = ArraySortedList(n)

        # Adding monsters from self.team into temp
        # Reverse the sort_key by making them change from positives -> negatives (and vice versa)
        while not self.team.is_empty():
            item = self.team.delete_at_index(0)
            item.key *= -1

            temp.add(item)

        # Update self.team to temp and increment special_optimise() calls
        self.team = temp
        self.special_count += 1

    def regenerate_team(self) -> None:
        """ Complexity is the same as make_copy() """
        # Refer to the initial array
        self.team = self.make_copy(self.initial)

    def select_randomly(self):
        team_size = RandomGen.randint(1, self.TEAM_LIMIT)
        monsters = get_all_monsters()
        n_spawnable = 0

        for x in range(len(monsters)):
            if monsters[x].can_be_spawned():
                n_spawnable += 1

        for _ in range(team_size):
            spawner_index = RandomGen.randint(0, n_spawnable-1)
            cur_index = -1
            for x in range(len(monsters)):
                if monsters[x].can_be_spawned():
                    cur_index += 1
                    if cur_index == spawner_index:
                        # Spawn this monster
                        self.add_to_team(monsters[x]())
                        break
            else:
                raise ValueError("Spawning logic failed.")

    def select_manually(self):
        """
        Prompt the user for input on selecting the team.
        Any invalid input should have the code prompt the user again.

        First input: Team size. Single integer
        For _ in range(team size):
            Next input: Prompt selection of a Monster class.
                * Should take a single input, asking for an integer.
                    This integer corresponds to an index (1-indexed) of the helpers method
                    get_all_monsters()
                * If invalid of monster is not spawnable, should ask again.

        Add these monsters to the team in the same order input was provided. Example interaction:

        How many monsters are there? 2
        MONSTERS Are:
        1: Flamikin [✔️]
        2: Infernoth [❌]
        3: Infernox [❌]
        4: Aquariuma [✔️]
        5: Marititan [❌]
        6: Leviatitan [❌]
        7: Vineon [✔️]
        8: Treetower [❌]
        9: Treemendous [❌]
        10: Rockodile [✔️]
        11: Stonemountain [❌]
        12: Gustwing [✔️]
        13: Stormeagle [❌]
        14: Frostbite [✔️]
        15: Blizzarus [❌]
        16: Thundrake [✔️]
        17: Thunderdrake [❌]
        18: Shadowcat [✔️]
        19: Nightpanther [❌]
        20: Mystifly [✔️]
        21: Telekite [❌]
        22: Metalhorn [✔️]
        23: Ironclad [❌]
        24: Normake [❌]
        25: Strikeon [✔️]
        26: Venomcoil [✔️]
        27: Pythondra [✔️]
        28: Constriclaw [✔️]
        29: Shockserpent [✔️]
        30: Driftsnake [✔️]
        31: Aquanake [✔️]
        32: Flameserpent [✔️]
        33: Leafadder [✔️]
        34: Iceviper [✔️]
        35: Rockpython [✔️]
        36: Soundcobra [✔️]
        37: Psychosnake [✔️]
        38: Groundviper [✔️]
        39: Faeboa [✔️]
        40: Bugrattler [✔️]
        41: Darkadder [✔️]
        Which monster are you spawning? 38
        MONSTERS Are:
        1: Flamikin [✔️]
        2: Infernoth [❌]
        3: Infernox [❌]
        4: Aquariuma [✔️]
        5: Marititan [❌]
        6: Leviatitan [❌]
        7: Vineon [✔️]
        8: Treetower [❌]
        9: Treemendous [❌]
        10: Rockodile [✔️]
        11: Stonemountain [❌]
        12: Gustwing [✔️]
        13: Stormeagle [❌]
        14: Frostbite [✔️]
        15: Blizzarus [❌]
        16: Thundrake [✔️]
        17: Thunderdrake [❌]
        18: Shadowcat [✔️]
        19: Nightpanther [❌]
        20: Mystifly [✔️]
        21: Telekite [❌]
        22: Metalhorn [✔️]
        23: Ironclad [❌]
        24: Normake [❌]
        25: Strikeon [✔️]
        26: Venomcoil [✔️]
        27: Pythondra [✔️]
        28: Constriclaw [✔️]
        29: Shockserpent [✔️]
        30: Driftsnake [✔️]
        31: Aquanake [✔️]
        32: Flameserpent [✔️]
        33: Leafadder [✔️]
        34: Iceviper [✔️]
        35: Rockpython [✔️]
        36: Soundcobra [✔️]
        37: Psychosnake [✔️]
        38: Groundviper [✔️]
        39: Faeboa [✔️]
        40: Bugrattler [✔️]
        41: Darkadder [✔️]
        Which monster are you spawning? 2
        This monster cannot be spawned.
        Which monster are you spawning? 1
        """
        """
        :complexity: best/worst = O(m) + O(n), where
            
            m is the number of monsters chosen by user
            O(n) is the time complexity of get_all_monsters()
        """
        # Validate user input for team's capacity
        while True:
            monster_num = self.validate_integer_input("How many monsters are there? \n")

            if monster_num <= self.TEAM_LIMIT:
                break
            else:
                print("Exceeded the team's capacity!")

        monster_list = get_all_monsters()
        
        # Display monsters list
        print("MONSTERS Are: ")
        for i in range(len(monster_list)):
            
            monster:MonsterBase = monster_list[i]
            spawn_possibility = "[✔️]" if monster.can_be_spawned() else "[❌]"

            print(f"{i+1}: {monster.get_name()} {spawn_possibility}")

        # Prompt and validate user input
        for _ in range(monster_num):
            while True:
                try:
                    number_chosen = self.validate_integer_input("Which monster are you spawning? \n")
                    monster_chosen:MonsterBase = monster_list[number_chosen-1]()

                    if monster_chosen.can_be_spawned():
                        self.add_to_team(monster_chosen)
                        break
                    else:
                        print("This monster cannot be spawned. Choose again!")

                except IndexError:
                    print("Invalid number choice!")

    # Additional method to ensure a valid positive integer is inputted by user
    def validate_integer_input(self,message) -> int:
        while True:
            try:
                num = int(input(message))

                if num <= 0:
                    raise ValueError
                else:
                    return num
                
            except ValueError:
                print("Value has to be a positive integer!")

    def select_provided(self, provided_monsters:Optional[ArrayR[type[MonsterBase]]]=None):
        """
        Generates a team based on a list of already provided monster classes.

        While the type hint implies the argument can be none, this method should never be called without the list.
        Monsters should be added to the team in the same order as the provided array.

        Example input:
        [Flamikin, Aquariuma, Gustwing] <- These are all classes.

        Example team if in TeamMode.FRONT:
        [Gustwing Instance, Aquariuma Instance, Flamikin Instance]
        """
        """
        :complexity: O(n) + O(m), where

            n is the number of elements in provided_monsters
            O(m) is the complexity of can_be_spawned()
        """
        if len(provided_monsters) > self.TEAM_LIMIT:
            raise ValueError("Exceeded the team's capacity!")

        # Creating new monster instance for each monster class in provided_monsters
        # and add to monster team
        for monster_class in provided_monsters:
            monster:MonsterBase = monster_class()

            # Raise ValueError if one of the monsters provided is not spawnable
            if monster.can_be_spawned():
                self.add_to_team(monster)
            else:
                raise ValueError(f"Monster {monster.get_name()} is not spawnable!")

    def choose_action(self, currently_out: MonsterBase, enemy: MonsterBase) -> Battle.Action:
        # This is just a placeholder function that doesn't matter much for testing.
        from battle import Battle
        if currently_out.get_speed() >= enemy.get_speed() or currently_out.get_hp() >= enemy.get_hp():
            return Battle.Action.ATTACK
        return Battle.Action.SWAP
    
    def __len__(self):
        return len(self.team)

if __name__ == "__main__":
    team = MonsterTeam(
        team_mode=MonsterTeam.TeamMode.OPTIMISE,
        selection_mode=MonsterTeam.SelectionMode.RANDOM,
        sort_key=MonsterTeam.SortMode.HP,
    )
    print(team)

    while len(team):
        print(team.retrieve_from_team())