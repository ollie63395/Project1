from __future__ import annotations
from enum import auto
from typing import Optional

from base_enum import BaseEnum
from team import MonsterTeam

class Battle:

    class Action(BaseEnum):
        ATTACK = auto()
        SWAP = auto()
        SPECIAL = auto()

    class Result(BaseEnum):
        TEAM1 = auto()
        TEAM2 = auto()
        DRAW = auto()

    def __init__(self, verbosity=0) -> None:
        self.verbosity = verbosity

    def process_turn(self) -> Optional[Battle.Result]:
        """
        Process a single turn of the battle. Should:
        * process actions chosen by each team
        * level and evolve monsters
        * remove fainted monsters and retrieve new ones.
        * return the battle result if completed.
        """
        """
        :complexity:
            team_mode FRONT: best/worst = O(a+b+m*(c+n)) - referenced in attack() from monster_base.py

            a is O(get_simple_stats())
            b is O(get_complex_stats())
            c is O(get_element())

            m is the number of elements in class Element
            n is the length of the array self.element_names in Element
        """
        # Action: SWAP 
        if self.action1 == self.Action.SWAP:
            self.team1.add_to_team(self.out1)
            self.out1 = self.team1.retrieve_from_team()

        if self.action2 == self.Action.SWAP:
            self.team2.add_to_team(self.out2)
            self.out2 = self.team2.retrieve_from_team()

        # Action: SPECIAL
        if self.action1 == self.Action.SPECIAL:
            self.team1.add_to_team(self.out1)
            self.team1.special()

            self.out1 = self.team1.retrieve_from_team()

        if self.action2 == self.Action.SPECIAL:
            self.team2.add_to_team(self.out2)
            self.team2.special()

            self.out2 = self.team2.retrieve_from_team()

        # Action: ATTACK
        if self.action1 == self.Action.ATTACK and self.action2 == self.Action.ATTACK:
            # Case 1: Monster 1 and Monster 2 have the same speed
            if self.out1.get_speed() == self.out2.get_speed():
                self.out1.attack(self.out2)
                self.out2.attack(self.out1)

            # Case 2: Monster 1 is faster than Monster 2
            elif self.out1.get_speed() > self.out2.get_speed():
                self.out1.attack(self.out2)

                if self.out2.get_hp() > 0:
                    self.out2.attack(self.out1)

            # Case 3: Monster 2 is faster than Monster 1
            else:
                self.out2.attack(self.out1)

                if self.out1.get_hp() > 0:
                    self.out1.attack(self.out2)
        
        # Team 1 attacks but team 2 does not
        elif self.action1 == self.Action.ATTACK:
            self.out1.attack(self.out2)

        # Team 2 attacks but team 1 does not
        else:
            self.out2.attack(self.out1)

        # Subtract 1 HP each if both monsters survived
        if self.out1.get_hp() > 0 and self.out2.get_hp() > 0:
            self.out1.set_hp(self.out1.get_hp() - 1)
            self.out2.set_hp(self.out2.get_hp() - 1)

        # Leveling up and, if possible, evolve
        if self.out1.get_hp() > 0 and self.out2.get_hp() <= 0:
            self.out1.level_up()

            try:
                self.out1 = self.out1.evolve()
            except ValueError:
                pass

        elif self.out1.get_hp() <= 0 and self.out2.get_hp() > 0:
            self.out2.level_up()

            try:
                self.out2 = self.out2.evolve()
            except ValueError:
                pass

        # Team 1's monster has fainted
        if self.out1.get_hp() <= 0:
            try:
                self.out1 = self.team1.retrieve_from_team()
            # Team 1 is empty
            except Exception:
                # Team 2's current monster is still alive (team 2 wins)
                if self.out2.get_hp() > 0:
                    return self.Result.TEAM2

                try:
                    # Team 2's current monster has also fainted
                    self.out2 = self.team2.retrieve_from_team()
                except Exception:
                    # And team 2 is also empty (draw)
                    return self.Result.DRAW
                else:
                    # And team 2 is not emtpy (team 2 wins)
                    return self.Result.TEAM2

            # Team 1 is not empty   
            else:
                # Team 2's current monster has fainted
                if self.out2.get_hp() <= 0:
                    try:
                        self.out2 = self.team2.retrieve_from_team()
                    except Exception:
                        # And team 2 is empty (team 1 wins)
                        return self.Result.TEAM1
                    
        # Team 1's current monster is not fainted
        else:
            # Team 2's current monster has fainted
            if self.out2.get_hp() <= 0:
                try:
                    # And team 2 is not empty
                    self.out2 = self.team2.retrieve_from_team()
                except Exception:
                    # And team 2 is empty (team 1 wins)
                    return self.Result.TEAM1

    def battle(self, team1: MonsterTeam, team2: MonsterTeam) -> Battle.Result:
        """

        """
        if self.verbosity > 0:
            print(f"Team 1: {team1} vs. Team 2: {team2}")

        self.team1 = team1
        self.team2 = team2

        self.out1 = team1.retrieve_from_team()
        self.out2 = team2.retrieve_from_team()

        # Assume choose_action has complexity O(1)
        self.action1 = self.team1.choose_action(self.out1, self.out2)
        self.action2 = self.team2.choose_action(self.out2, self.out1)

        result = None

        while result is None:
            result = self.process_turn()

        return result

if __name__ == "__main__":
    t1 = MonsterTeam(MonsterTeam.TeamMode.BACK, MonsterTeam.SelectionMode.RANDOM)
    t2 = MonsterTeam(MonsterTeam.TeamMode.BACK, MonsterTeam.SelectionMode.RANDOM)
    b = Battle(verbosity=3)
    print(b.battle(t1, t2))